import React, { Component } from 'react';
import './App.css';
import { connect } from 'react-redux';
import * as AnimalActions from './Store/actions/actions'


class App extends Component {



  componentDidMount(){

    this.props.onAnimalFetch()
  }

  render() {

    // let animal=[...this.props.ani]    //coverting state into array
    // animal.map(aniKey=>{
    //   return (
    //   <ul>
    //     <li>{aniKey}</li>
    //   </ul>
    //   )
    // })



    
    return (
      <div className="App">
      {this.props.err && <span >{this.props.err}</span>}

      <ul>
       
       {this.props.ani.map(animal=>{
         return <li>{animal}</li>
       })}

      </ul>

      </div>
    );
  }
}


const mapStateToProps= state =>
{
  return{
    ani:state.Animals,
    err:state.error
  }

}

const mapDispatchToProps=dispatch=>{
  return{
    onAnimalFetch:()=>dispatch(AnimalActions.FetchAnimal())
  }
}
export default   connect(mapStateToProps,mapDispatchToProps) (App);
